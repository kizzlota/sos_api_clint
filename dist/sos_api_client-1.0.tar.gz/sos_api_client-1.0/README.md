![sos api client](sos.svg)
# StarOfService api client 