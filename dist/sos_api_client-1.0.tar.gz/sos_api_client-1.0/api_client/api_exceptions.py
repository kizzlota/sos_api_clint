class SoSApiException(Exception):
    pass


class SosApiStatusException(Exception):
    pass
